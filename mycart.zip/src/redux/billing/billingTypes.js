export const ADD_DETAILS = "ADD_DETAILS"

export const UPDATE_DETAILS = "UPDATE_DETAILS"
