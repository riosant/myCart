const NotFound = () => {
    return (
        <h1>
            <i className="fas fa-caret-right"/> Oops! This page doesn't exist...
        </h1>
    )
}

export default NotFound